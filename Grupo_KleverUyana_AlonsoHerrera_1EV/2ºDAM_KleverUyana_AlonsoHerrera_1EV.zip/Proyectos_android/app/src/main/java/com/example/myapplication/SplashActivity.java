package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.widget.TextView;

import pl.droidsonroids.gif.GifImageView;

/**
 * The type Splash activity.
 */
public class SplashActivity extends AppCompatActivity {
    /**
     * The View.
     */
    TextView view;
    /**
     * The Gif image view.
     */
    GifImageView gifImageView;
    /**
     * The Counter.
     */
    static int counter = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        view = findViewById(R.id.texcarga);
        gifImageView = findViewById(R.id.gifload);

        new CountDownTimer(6000,60){


            @Override
            public void onTick(long millisUntilFinished) {
                counter++;
                view.setText(counter+" %");
            }

            @Override
            public void onFinish() {
                view.setText("Complete");
                gifImageView.setImageResource(R.drawable.loading);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent(SplashActivity.this,MainActivity.class);
                        SplashActivity.this.startActivity(intent);
                        counter=0;
                        SplashActivity.this.finish();
                    }
                },1000);
            }
        }.start();
    }
}
