package com.example.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;

/**
 * The type Main activity.
 * Esta activity contiene en menu de inicio de la app
 */
public class MainActivity extends Activity {

    /**
     * The Media player.
     */
    MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.setVolumeControlStream(AudioManager.STREAM_MUSIC);

        mediaPlayer = new MediaPlayer();

    }

    /**
     * play_mu
     * reprocuse la musica
     */
    private void play_mu(){
        Thread playThead = new Thread(){
            public void run(){
                mediaPlayer = MediaPlayer.create(MainActivity.this,R.raw.musica2);
                mediaPlayer.start();
            }
        };
        playThead.start();
    }

    /**
     * Stop mu.
     * para la musica
     */
    public void stop_mu(){
        mediaPlayer.stop();
    }

    /**
     * Ejecutar juego.
     *  reprodure musica y la a JuegoActivity
     * @param view the view
     */
    public void ejecutar_juego(View view){
        play_mu();
        Intent j= new Intent(this, JuegoActivity.class);
        startActivity(j);
    }

    /**
     * Ejecutar info.
     * para la musica y va a InfoActivity
     * @param view the view
     */
    public void ejecutar_info(View view){
        stop_mu();
        Intent i= new Intent(this, InfoActivity.class);
        startActivity(i);
    }

    /**
     * Salir app.
     * Para la musica y sale del juego
     * @param view the view
     */
    public void salirApp(View view){
        stop_mu();
        finish();
    }
}
