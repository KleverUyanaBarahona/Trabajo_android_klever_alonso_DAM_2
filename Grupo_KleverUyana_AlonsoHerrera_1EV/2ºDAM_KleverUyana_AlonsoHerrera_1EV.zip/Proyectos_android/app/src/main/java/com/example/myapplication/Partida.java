package com.example.myapplication;

//almacena difucultad.

import android.os.Parcel;
import android.os.Parcelable;

import java.util.Random;

/**
 * The type Partida.
 * Classe para la partida
 */
public class Partida {

    /**
     * Instantiates a new Partida.
     *  Estable todas las casillas a 0.
     * @param dificultad the dificultad
     */
    public Partida(int dificultad){

    this.dificultad = dificultad;

        jugador = 1;

        // otra array de casillas que empiezan de 0
        casillas = new int[9];
        for(int i = 0;i < 9;i++){
        casillas[i] = 0;
        }
    }

    /**
     * Comprueba casilla boolean.
     * //comprobar si la casilla esta utilizada// la array_2 de 0
     * @param casilla the casilla
     * @return the boolean
     */

    public boolean comprueba_casilla(int casilla){
        if(casillas[casilla] != 0){
            return false;
        }else{
            casillas[casilla] = jugador;
        }
        return true;
    }

    /**
     * Turno int.
     * //para cambiar de jugador
     * @return the int
     */

    public int turno(){

        boolean empate = true;

        boolean ult_movimiento = true;

        for(int i = 0;i < COMBINACIONES.length;i++) {
            for(int pos:COMBINACIONES[i]) {
                System.out.println("Valor en posicion "+pos+" "+ casillas[pos]);

                if(casillas[pos] != jugador)ult_movimiento=false;

                if(casillas[pos] == 0){
                    empate = false;
                }
            }//for anidado
            // para verlo en consola
            System.out.println("-----------------------------------------------------------------");
            if(ult_movimiento)return jugador;

            ult_movimiento = true;

        }//for cierre
        //empate = true
        if (empate){
            return 3;
        }

        jugador++;
        if(jugador > 2){
            jugador = 1;
        }
        return 0;
    }


    /**
     * Dos en raya int.
     * //promprobar cuantas casillas llevan los jugadores para ganar.
     * //metodo clave
     * @param jugador_en_turno the jugador en turno
     * @return the int
     */

    public int dosEnRaya(int jugador_en_turno){

        int casilla = -1;
        int cuantas_lleva = 0;

        for(int i = 0;i<COMBINACIONES.length;i++) {
            for(int pos:COMBINACIONES[i]) {

                if(casillas[pos] == jugador_en_turno) cuantas_lleva++;

                if(casillas[pos] == 0) casilla = pos;
            }
            if(cuantas_lleva == 2 && casilla != -1)return casilla;
            casilla =- 1;

            cuantas_lleva = 0;
        }
        return -1;
    }

    /**
     * Ia int.
     * // creamos instancia, almacenamos en casilla lo que nos devuelve nextInt()
     * // intento de inteligencia para tres en raya dependiendo del nivel de dificultad
     * @return the int
     */

    public int ia(){
        int casilla;

        casilla = dosEnRaya(2);

        if(casilla != -1)return casilla;

        if(dificultad > 0){
            casilla = dosEnRaya(1);
            if(casilla != -1)return casilla;
        }

        if(dificultad == 2){
            if(casillas[0] == 0)return 0;
            if(casillas[2] == 0)return 2;
            if(casillas[6] == 0)return 6;
            if(casillas[8] == 0)return 8;
        }
        //si en facil el Ramdom
        Random casilla_azar = new Random();
        casilla = casilla_azar.nextInt(9);
        return casilla;
    }

    /**
     * The Dificultad.
     */
    public final int dificultad;

    /**
     * The Jugador.
     */
    public int jugador;

    private int[] casillas;

    //Combinacione posibles
    private final int[][] COMBINACIONES= {{0,1,2},{3,4,5},{6,7,8},{0,3,6},{1,4,7},{2,5,8},{0,4,8},{2,4,6}};

}
