package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Toast;

/**
 * The type Juego activity.
 * Esta activity es donde se va realizar toda la interaccion del juego.
 */
public class JuegoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juego);

        //iniciamos el array casilla que identifica cada casilla y la almacena en el array

        CASILLAS = new int[9];

        CASILLAS[0]=R.id.a1;
        CASILLAS[1]=R.id.a2;
        CASILLAS[2]=R.id.a3;
        CASILLAS[3]=R.id.b1;
        CASILLAS[4]=R.id.b2;
        CASILLAS[5]=R.id.b3;
        CASILLAS[6]=R.id.c1;
        CASILLAS[7]=R.id.c2;
        CASILLAS[8]=R.id.c3;

    }

    /**
     * A jugar.
     *
     * //recores el array casillas de elemento a elemento, a cada elemento del array
     * //identifica cada casilla como una imagen, almaceno el id de cada casilla dentro de variable imagen
     * // y la utilizo para que cada vuelta de bucle, para que cuando estemos evaluando,
     * //le asigne la casilla en blanco, para limpiar el tablero
     *
     * @param vista the vista
     */
    public  void aJugar(View vista){

        ImageView imagen;

        for(int cadaCasilla:CASILLAS){
            imagen=(ImageView)findViewById((cadaCasilla));

            imagen.setImageResource(R.drawable.casilla);

        }

        jugadores = 1;

        if(vista.getId()==R.id.info){
            jugadores = 2;

        }
//identificar y almacenar el grupo de radios

        RadioGroup configDificultad = (RadioGroup)findViewById(R.id.configD);
        //detectar el nivel
        int id=configDificultad.getCheckedRadioButtonId();

        int dificultad = 0;

        if(id == R.id.normal){
            dificultad = 1;
        }else if(id == R.id.impocible){
            dificultad = 2;
        }

        partida = new Partida(dificultad);

        //inavilitar botones y radios
        ((Button)findViewById(R.id.jugar)).setEnabled(false);
        ((RadioGroup)findViewById(R.id.configD)).setAlpha(0);
        ((Button)findViewById(R.id.info)).setEnabled(false);



    }

    /**
     * Toque.
     *
     * //resibimos una casilla por parametro
     * //y recoremos el array de las casillas para saber que casilla a sido pulsada
     * //y sale con break en cuanto lo encuentre
     *
     * @param mivista the mivista
     */
    public void toque(View mivista){

        //si no escoges nivel

        if(partida == null){
            return;
        }

        int casilla = 0;

        for(int i = 0;i < 9;i++){

            if(CASILLAS[i] == mivista.getId()){
                casilla = i;
                break;
            }
        }
//mandar un mesage que te dice la casilla que pulsas
       /* Toast toast=Toast.makeText(this,"Has pulsado la casilla"+casilla,Toast.LENGTH_LONG);
        toast.setGravity(Gravity.CENTER,0,0);
        toast.show();*/

        //comprobar si esta utilizada,
        if(partida.comprueba_casilla(casilla) == false){
            return;
        }
        marca(casilla);


        int resultado = partida.turno();
        if(resultado>0){
            termina(resultado);

            return;
        }

        //sobreescribir el valor de casilla para que el programa
        //almacene su casilla
        if(jugadores == 1){
            casilla = partida.ia();

            while (partida.comprueba_casilla(casilla)!=true){
                casilla=partida.ia();
            }

            //para cambiar de jugador

            marca(casilla);
            //para volver a turno 1
            resultado = partida.turno();
            if(resultado>0){
                termina(resultado);
            }
        }

    }

    private void termina (int resultado){

        String mensaje;

        if(resultado == 1){
            mensaje = getString(R.string.circulos_ganan);
            contador_circulos++;}
        else if(resultado == 2) {
            mensaje = getString(R.string.aspas_ganan);
            contador_cruzes++;
        }
        else {
            mensaje = getString((R.string.empate));
        contador_empates++;
        }

        Toast toast = Toast.makeText(this,mensaje,Toast.LENGTH_LONG);
        toast.setGravity(Gravity.CENTER,0,0);
        toast.show();

        partida = null;
        ((Button)findViewById((R.id.jugar))).setEnabled(true);
        ((RadioGroup)findViewById(R.id.configD)).setAlpha(1);
        ((Button)findViewById((R.id.info))).setEnabled(true);


    }

    //dibuja con circulo o cruz
    //dependiendo del jugador

    private void marca(int casilla){
        ImageView imagen;

        imagen=(ImageView)findViewById(CASILLAS[casilla]);

        if(partida.jugador == 1){
            imagen.setImageResource(R.drawable.circulo);
        }else{
            imagen.setImageResource(R.drawable.aspa);
        }

    }

    private int jugadores;

    private int[] CASILLAS;

    private Partida partida;

    private int contador_cruzes=0;

    private int contador_circulos=0;

    private int contador_empates=0;

    //no he podido guardas el estado de la clase partida ya que es un objeto
    //he buscado informacion, pero no he conseguido implementarlo.
    //por lo que nos concentramos en guardar el numero de partidas
    //ganadas por cada uno de los elemtos (cruzes y circulos)
    @Override
    public void onSaveInstanceState(Bundle outState) {
        //outState.putInt("jugadores",jugadores);
        //outState.putIntArray("casillas",CASILLAS);
        //outState.putSerializable("partida", (Serializable) partida);
        super.onSaveInstanceState(outState);


    }

    @Override
    public void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {

        super.onRestoreInstanceState(savedInstanceState);
        //jugadores=savedInstanceState.getInt("jugadores");
        //CASILLAS=savedInstanceState.getIntArray("casillas");
        //partida= (Partida) savedInstanceState.getSerializable("partida");
    }

    /**
     * Ejecutar result.
     * //pasar datos a otra activiti.
     * @param view the view
     */

    public void ejecutar_result(View view){

        Intent r= new Intent(this, Result_Activity.class);
        r.putExtra("contador_circulos",contador_circulos);
        r.putExtra("contador_cruzes",contador_cruzes);
        r.putExtra("contador_empate",contador_empates);
        startActivity(r);
    }
}
