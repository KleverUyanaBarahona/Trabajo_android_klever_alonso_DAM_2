package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

/**
 * The type Result activity.
 */
public class Result_Activity extends AppCompatActivity implements OnClickListener {

    final private int REQUEST_CODE_ASK_PERMISSION = 111;
    /**
     * The Num 1.
     */
    int num1;
    /**
     * The Num 2.
     */
    int num2;
    /**
     * The Num 3.
     */
    int num3;
    /**
     * The Num 4.
     */
    int num4;
    /**
     * The Escritura.
     */
    String escritura;

    /**
     * The Leermeminterna.
     */
//creados para ser enlazados
    Button leermeminterna;
    /**
     * The Escribirmeminterna.
     */
    Button escribirmeminterna;
    /**
     * The Leersd.
     */
    Button leersd;
    /**
     * The Escribirsd.
     */
    Button escribirsd;
    /**
     * The Leerprograma.
     */
    Button leerprograma;
    /**
     * The Text view.
     */
    TextView textView;
    /**
     * The Sd disponible.
     */
    boolean sdDisponible = false;
    /**
     * The Sd acceso escritura.
     */
    boolean sdAccesoEscritura = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_);

        solicitarPermisos();
        //enlazamiento.
        leermeminterna = (Button)findViewById(R.id.leermeminterna);
        escribirmeminterna = (Button)findViewById(R.id.escribirmeninterna);
        leersd = (Button)findViewById(R.id.leersd);
        escribirsd = (Button)findViewById(R.id.escribirsd);
        leerprograma = (Button)findViewById(R.id.leerprograma);
        textView = (TextView) findViewById(R.id.textView3);

        leermeminterna.setOnClickListener(this);
        escribirmeminterna.setOnClickListener(this);
        leersd.setOnClickListener(this);
        escribirsd.setOnClickListener(this);
        leerprograma.setOnClickListener(this);

        //Comprueba si exite SD y si puedo escribir o no
        String estado = Environment.getExternalStorageState();

        if(estado.equals(Environment.MEDIA_MOUNTED))
        {
            sdDisponible = true;
            sdAccesoEscritura = true;
        }
        else if(estado.equals(Environment.MEDIA_MOUNTED_READ_ONLY))
        {
            sdDisponible = true;
            sdAccesoEscritura = false;
        }
        else {
            sdDisponible = false;
            sdAccesoEscritura = false;
        }

        Bundle datos=getIntent().getExtras();
        LoadData();
        num1 = datos.getInt("contador_circulos");
        num2 = datos.getInt("contador_cruzes");
        num3 = datos.getInt("contador_empate");
        num4 = num1 + num2 + num3;
        escritura = "Totales:" + num4 + "|Circulos:" + num1 + "|Cruzes:" + num2 + "|Empates:" + num3;

        TextView valor_total = (TextView)findViewById(R.id.total);
        valor_total.setText("Total Partidas : " + num4);

        TextView valor_total_circulos = (TextView)findViewById(R.id.total_circulos);
        valor_total_circulos.setText("Circulos : " + num1);

        TextView valor_total_cruzes = (TextView)findViewById(R.id.total_cruzes);
        valor_total_cruzes.setText("Cruzes : " + num2);

        TextView valor_total_empates = (TextView)findViewById(R.id.total_empates);
        valor_total_empates.setText("Empates : " + num3);

    }

    //Para guardarlo en Prefereces.xml Accedemos y lo hacemos editable.
    @Override
    protected void onPause() {
        super.onPause();
        saveData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences datos=PreferenceManager.getDefaultSharedPreferences(this);
        num1 = datos.getInt("c_ci",0);
        num2 = datos.getInt("c_cr",0);
        num3 = datos.getInt("c_em",0);
        num4 = datos.getInt("c_tot",0);
    }

    /**
     * Save data.
     */
    public void saveData(){
        SharedPreferences sharedPreferences = getSharedPreferences("saveCounters",MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putInt("c_ci", num1);
        editor.putInt("c_cr", num2);
        editor.putInt("c_em", num3);
        editor.putInt("c_tot", num4);
    }

    /**
     * Load data.
     */
    public  void LoadData(){
        SharedPreferences sharedPreferences = getSharedPreferences("saveCounters",MODE_PRIVATE);
        num1=sharedPreferences.getInt("c_ci",MODE_PRIVATE);
        num2=sharedPreferences.getInt("c_cr",MODE_PRIVATE);
        num3=sharedPreferences.getInt("c_em",MODE_PRIVATE);
        num4=sharedPreferences.getInt("c_tot",MODE_PRIVATE);
    }
    //para dar mermisos a la aplicacion en tiempo de ejecucion.
    private void solicitarPermisos(){
        int permisosStorage = ActivityCompat.checkSelfPermission(Result_Activity.this, Manifest.permission.READ_EXTERNAL_STORAGE);
        int permisosdescritura = ActivityCompat.checkSelfPermission(Result_Activity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if(permisosStorage!= PackageManager.PERMISSION_GRANTED || permisosdescritura!=PackageManager.PERMISSION_GRANTED){
            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ){
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE},REQUEST_CODE_ASK_PERMISSION);

            }
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){

            case(R.id.leermeminterna):

                try
                {
                    BufferedReader fin = new BufferedReader(new InputStreamReader(openFileInput("meminterna.txt")));
                    String texto = fin.readLine();
                    textView.setText(texto);
                }
                catch(Exception ex)
                {
                    Log.e("Fichero: ","Error al leer fichero desde la memoria interna");
                }

                break;
            case(R.id.escribirmeninterna):
                try
                {
                OutputStreamWriter fout = new OutputStreamWriter(openFileOutput("meminterna.txt",Context.MODE_PRIVATE));
                fout.write("M.I."+escritura);
                fout.close();
                }
                    catch(Exception ex)
                {
                    Log.e("Fichero: ","Error al escribir fichero desde la memoria interna");
                }

                break;
            case(R.id.leersd):
                if(sdDisponible){
                    try
                    {
                        File ruta_sd = Environment.getExternalStorageDirectory();
                        File f = new File(ruta_sd.getAbsolutePath(),"ficherosd.txt");
                        BufferedReader fin = new BufferedReader(new InputStreamReader(new FileInputStream(f)));

                        String texto = fin.readLine();
                        textView.setText(texto);
                        fin.close();
                    }
                    catch (Exception ex)
                    {

                    }
                }
                break;
            case(R.id.escribirsd):
                if(sdAccesoEscritura && sdDisponible){
                    try
                    {
                        File ruta_sd = Environment.getExternalStorageDirectory();
                        File f = new File(ruta_sd.getAbsolutePath(),"ficherosd.txt");
                        OutputStreamWriter fout = new OutputStreamWriter(new FileOutputStream(f));

                        fout.write("M.E."+escritura);
                        fout.close();
                    }
                    catch (Exception ex)
                    {

                    }
                }
                break;
            case(R.id.leerprograma):
                try
                {
                    InputStream fraw = getResources().openRawResource(R.raw.ficheroraw);

                    BufferedReader brin = new BufferedReader(new InputStreamReader(fraw));
                    String linea = brin.readLine();
                    textView.setText(linea);
                    fraw.close();
                }
                catch (Exception ex)
                {
                    Log.e("Fichero: ","Error al leer fichero desde recurcos raw");

                }

                    break;
                default:
                    break;
        }
    }
}
